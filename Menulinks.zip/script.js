//SELECIONAR COM QUERYSELECTOR()
const vermelho = document.querySelector('.vermelho')
const verde = document.querySelector('.verde')
const rosa = document.querySelector('.rosa')
const amarelo = document.querySelector('.amarelo')
const conteudo = document.querySelector('.conteudo')
const bigText = document.querySelector('.big-text')

//alert(vermelho)

vermelho.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'red'
  bigText.style.color = '#fff'
})

verde.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'green'
  bigText.style.color = '#fff'
})

rosa.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'pink'
  bigText.style.color = '#fff'
})

amarelo.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'yellow'
  bigText.style.color = '#fff'
})






