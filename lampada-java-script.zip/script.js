const btnAlternar = document.getElementById('btn-alternar');
const imgLampada = document.getElementById('lampada');
const baseUrl = "https://39526240-1a49-40d3-ae5a-fb0cc8707167-00-2pb5z08n3tpo7.spock.replit.dev/"

btnAlternar.addEventListener('click', function() {
  if (imgLampada.src = baseUrl + 'lampada-0.png') {
    imgLampada.src = "lampada-2.png"
  } else {
    imgLampada.src = "lampada-0.png"
  }
})


