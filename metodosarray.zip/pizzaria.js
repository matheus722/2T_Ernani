/**
 /1) Crie um algoritmo que faça o seguinte:
  a) pergunte o nome do cliente e armazene em uma variável
  b) cumprimente o cliente e pergunte qual pizza ele quer pedir
  c) enquanto ele não tiver feito 3 pedidos continue perguntando
  d) a cada pedido feito, adicione o sabor escolhido a um array
  e) ao final, informe ao cliente a quantidade de pizzas do pedido
  f) imprima quais pizzas foram pedidas
*/
let sabores = [] // CRIAR UM ARRAY VAZIO
let pedidos = 0



const cliente = prompt("Ola qual e seu nome?")
if (cliente){
alert(" Ola " + cliente + ", seja bem vindo (a)!")

//LOOP DE REPETIÇAO INFINITO (QUE RODA ENQUANDO UMA CONDIÇÃO FOR VERDADEIRA))
while (pedidos < 3) {
  
  let sabor = prompt("🍕 Qual sabor de pizza voce gostaria? ")
  if (sabor) {
    sabores.push(sabor) //ENVIAR PARA NOSSA LISTA
    alert("Pedido recebido!")

  }
  //CHECAR COM IF SE O NOME DE USUARIO EXISTE

  pedidos = pedidos + 1 // ACUMULO DE VALORES
}
//IMPRIMIR LISTA
alert("Pedido fechado com sucesso! Olhe seu log!")
console.log("------🍕 PIZZARIA KI-KAKI-GOSTOSO 🍕------")
console.log(sabores)
console.log("-------------------------------------")

} else {
  alert("por favor , digite seu nome!")
  
}