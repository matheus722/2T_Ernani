// METODOS DE ARRAY
const comidas = ['churrasco', 'pizza']
comidas[3] = 'macarronada'
comidas.push('berinjela') //EMPURRANDO UM VALOR PARA O FINAL DA LISTA
comidas.pop() //RETIRAR UM VALOR DO FINAL DA LISTA
comidas.shift()// INSERIR UM VALOR NO INICIO DO Dconsole
comidas.unshift('mamão')



const tamanho = comidas.length
console.log(" existem " + tamanho + " itens na lista ")//CONTAGEM DE ITENS
console.log(comidas) 