/**
 * FUNÇOES:São blocos de código que podem ser reaproveitados.
 * FUNÇOES:Funçoes podem ou nao ter nomes
 * Podem ou nao receber parametros
 */
// CRIAR OU DECLARAR FUNÇOES
function dizOla(nome) {
  // codigo
  console.log('Ola!' + nome)
}
//INVOCAR / CHAMAR FUNÇOES
dizOla('Flavio')
dizOla('Ana')
dizOla('nobru sacolao')
dizOla('fluxio tcho99')
dizOla('areexc')

//ADIÇAO
function somaDoisNumeros(x, y) {
  const soma = x + y
  console.log(soma)
}
somaDoisNumeros(5345, 6546)
somaDoisNumeros(5345, 5437)

//SUBTRAÇAO
function subtraiDoisNumeros(x, y) {
  const subtracao = x - y
  console.log(subtracao)
}
subtraiDoisNumeros(230, 40)
subtraiDoisNumeros(123, 456)

//MULTIPLICAÇAO

function multiplicaDoisNumeros(x, y) {
  const multiplicacao = x * y
  console.log(multiplicacao)
}
multiplicaDoisNumeros(70, 98)
multiplicaDoisNumeros(76, 87)

//DIVISAO

function divideDoisNumeros(x, y) {
  const divisao = x / y
  console.log(divisao)
}
divideDoisNumeros(70, 5)
divideDoisNumeros(10, 90)