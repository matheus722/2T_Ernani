function parOuimpar (x){
 if(typeof x === 'number'){
   if(x % 2 === 0){
     alert('0 numero ' + x + ' é par')
   }else{
     alert('0 numero ' + x + ' é impar')
   }
 }else{
   alert('Por favor insira um número válido')
   }

 }
parOuimpar(2)
parOuimpar(23)
parOuimpar("manga")