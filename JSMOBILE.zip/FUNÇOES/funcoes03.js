function dados (numero){
  if (numero % 2 === 0 ){
   alert ('0 numero ' +  numero + ' é par ')
  }else{alert('0 numero '  +  numero  + ' é impar ')}
}

dados( 22 )
dados( 333 )
dados( 444 )
dados( 555 )

