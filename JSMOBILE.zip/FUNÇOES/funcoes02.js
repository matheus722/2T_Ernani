function dados(nome, sobrenome) {
  if (typeof nome === 'string' && typeof sobrenome === 'string') {
    alert("ola" + "arthur" + "rosa")
  } else {
    alert("por favor insira um nome valido")
  }
}
dados('matheus', 'alemao')