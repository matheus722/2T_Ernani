// FUNCOES COM RETORNO
// SAO FUNCOES QUE RETORNAM UM VALOR
// PROCESSADOS
// PARA USO POSTERIOR
const nome = 'alemao'

function retornaDados(){
  //codigo com retorno
  return nome.toUpperCase()
  console.log('testando...')//INALCANÇAVEL
  // A PARTIR DESSA LINHA NAO EXECUTA MAIS NADA...
}
const dados = retornaDados()
console.log(dados)